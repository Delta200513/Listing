package List7;

public class list_7_2 {
}

package List2;

public class list_2_17 {
    public static void main(String[] args) {
        char ch = 'а';
        while (ch <= 'я') {
            System.out.println(ch);
            ch++;
        } // while
    } // main(String[]) method
} // AlphabetWhileDemo class
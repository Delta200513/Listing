package List2;

public class list_2_8 {
    public  static void main(String[] args) {
        boolean b;
        b = false;
        System.out.println("b = " + b);
        b = true;
        System.out.println("b = "+ b);
        if (b) System.out.println("Как вы думаете, увидете ли вы эту строку?");
        System.out.println("Выражение 10 > 9 имеет значение " + (10 > 9));
    } // main(String[] args)
} // BoolDemo class
